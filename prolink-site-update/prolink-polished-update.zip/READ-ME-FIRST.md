# Prolink website polish — cPanel update

This package updates the existing Laravel 12 website. It is not the earlier standalone resume website. It contains no production `.env`, database, administrator passwords, customer records, signatures, sessions, logs, or vendor dependencies.

## What changed

- Bespoke homepage with purple, powder blue, and restrained red accents; work appears before the service list.
- Shared typography, responsive spacing, card styles, banners, light/dark themes, footer, newsletter, and contact treatments across the public pages.
- Seven original project illustrations and owner-supplied project records. Illustrations are not client logos or screenshots. No fabricated dates, numerical outcomes, or endorsements were added.
- Dedicated Call and WhatsApp actions. The floating contact card opens only when clicked.
- Service enquiry links retain their chosen service. Articles recommend other published articles.
- Portfolio, article, and team listings display result counts.
- Improved management studio styling and keyboard-accessible mobile navigation.
- Purple branding in invoice/receipt PDFs without changing totals, document rules, or signature handling.
- Two old refinement stylesheet imports consolidated into one shared `studio.css`; legacy stored page HTML remains supported.

## Before updating

1. Make a backup of the current **prolink-app**, **public_html**, and database. Keep the backup outside public_html.
2. Prefer a staging copy/subdomain using its own database. Test and review there before updating the live site.
3. Keep your existing `.env`, `APP_KEY`, database, `vendor`, `storage`, and uploaded media. This is an overlay update, not a folder replacement. **Do not delete your existing folders.**

## File placement

The update ZIP has two folders:

- Copy the **contents of `prolink-app/`** into the existing `/home/YOUR_ACCOUNT/prolink-app/`, merging folders and replacing the included matching files.
- Copy the **contents of `public_html/`** into the domain's existing public_html, merging folders and replacing the included matching files.

The existing public_html `index.php` and `.htaccess` are intentionally not replaced. Their current connection to `../prolink-app` and PHP 8.3 handler remain valid. No Composer dependency changes or database migrations are required for this update. Old refinement CSS files may remain on disk; updated layouts no longer load them.

## Clear caches and add the project records

Using cPanel Terminal (or ask hosting support to run these with the site's PHP 8.3 executable):

```sh
cd /home/YOUR_ACCOUNT/prolink-app
php artisan optimize:clear
php artisan db:seed --class=PortfolioExperienceSeeder --force
php artisan db:seed --class=StudioDesignSeeder --force
```

The portfolio seeder inserts the seven supplied project records only if their URLs do not already exist. Running it again does not overwrite edited projects. The design seeder changes the homepage headline and description only if the headline still matches the shipped original default. It leaves an owner-customised headline unchanged. Do not run `migrate:fresh`, `key:generate`, or a full database reset.

The seven new project pages become published when the portfolio seeder runs. Review the copy and illustrations on staging before running it against the live database. Existing projects and other database content remain in place. You can edit/hide individual new project pages in the existing content manager.

If the server does not have Terminal, a technician can run the two seeder commands. The shared design works without running seeders, but the new projects and revised default homepage copy will not appear until then.

## Checks after upload

Check homepage, all seven service pages, portfolio search/filtering, project detail pages, about/team, article pages, contact, FAQ/legal pages, and both themes on desktop and phone. Test the menu with Tab and Escape. Submit a test enquiry and newsletter subscription you control, and check them in the dashboard. Review an invoice PDF before issuing real documents.

Local automated tests used a clean SQLite database, simulated email transport, and synthetic users. No live hosting data was changed. Email delivery, Apache/cPanel configuration, and production database permissions must be verified on staging/hosting. Existing statistics and testimonial records were preserved; review their accuracy before publication.

## Rollback

Restore the corresponding source/public files from your backup and run `php artisan optimize:clear`. If project seeders were run, hide the seven new project entries through the content manager if you do not want them displayed. Their URLs use descriptive slugs under `/project/`; original numbered project URLs remain intact. Restore the database backup only if needed and after accounting for any newer enquiries or edits.
