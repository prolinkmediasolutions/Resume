(() => {
  const widget = document.querySelector('.contact-widget');
  const card = widget?.querySelector('.contact-float');
  const launcher = widget?.querySelector('.contact-launcher');
  const close = widget?.querySelector('.contact-float-close');
  if (!card || !launcher || !close) return;
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const storageKey = 'prolink-contact-dismissed';
  let hideTimer, autoTimer;
  let isOpen = false;
  launcher.hidden = false;

  function setOpen(open, userAction = false) {
    clearTimeout(hideTimer); clearTimeout(autoTimer);
    isOpen = open;
    launcher.setAttribute('aria-expanded', String(open));
    launcher.setAttribute('aria-label', open ? 'Close Prolink contact card' : 'Open Prolink contact card');
    document.body.classList.toggle('contact-card-open', open);
    if (open) {
      card.hidden = false;
      card.inert = false;
      // Two frames ensure the starting transform is painted before the entrance.
      requestAnimationFrame(() => requestAnimationFrame(() => {
        if (!isOpen) return;
        widget.classList.add('is-open');
        if (userAction) close.focus({preventScroll: true});
      }));
    } else {
      widget.classList.remove('is-open');
      const restoreFocus = card.contains(document.activeElement);
      if (restoreFocus) launcher.focus({preventScroll: true});
      card.inert = true;
      if (userAction) { try { sessionStorage.setItem(storageKey, '1'); } catch {} }
      hideTimer = setTimeout(() => { if (!isOpen) card.hidden = true; }, reduced.matches ? 0 : 450);
    }
  }
  launcher.addEventListener('click', () => setOpen(!isOpen, true));
  close.addEventListener('click', () => setOpen(false, true));
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && isOpen) setOpen(false, true);
  });
  document.addEventListener('click', event => {
    if (isOpen && !widget.contains(event.target)) setOpen(false, true);
  });
  let dismissed = false;
  try { dismissed = sessionStorage.getItem(storageKey) === '1'; } catch {}
  if (widget.dataset.autoOpen === 'true' && !dismissed) autoTimer = setTimeout(() => {
    // Do not interrupt a form, a menu, or a hidden browser tab.
    if (document.hidden || document.body.classList.contains('menu-open') || document.activeElement?.matches('input,textarea,select,button')) return;
    setOpen(true);
  }, 4200);
})();
