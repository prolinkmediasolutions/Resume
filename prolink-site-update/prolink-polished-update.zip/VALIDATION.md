# Verified development results

Checked on an isolated development copy with PHP 8.4.24, Node 24, locked Composer/npm dependencies, and a clean SQLite database. Production is configured for PHP 8.3; no claim of execution on that host is made.

- PHP unit/feature suite: **20 tests passed, 565 assertions**. Existing 15 tests plus five new behaviour checks.
- Public browser sweep: **34 published pages**, each at widths **320, 390, 768, and 1440 px**. No horizontal document overflow or broken loaded images found; each page returned HTTP 200 with one main heading.
- Browser interactions: light/dark switch, service dropdown and Escape, mobile navigation and Escape, service selection carried into the enquiry form.
- Real local CSRF-protected enquiry and AJAX newsletter submissions succeeded. Records were created only in the isolated preview database, with simulated email transport.
- Admin: login plus six dashboard/content/enquiries/billing/settings screens checked, including phone layouts and keyboard menu operation. The first admin sweep used a synthetic user accidentally assigned the editor default; the correctly assigned administrator fixture passed all six screens. No production account was used or changed.
- Billing: synthetic invoice creation and downloadable PDF generation passed. No real document, customer signature, or email was used.
- Frontend build completed. PHP/Blade templates compiled. Exact dependency lockfiles retained.
- Both ZIP archives passed integrity checks. Runtime credentials, private signatures, databases, logs, installed dependencies, and sessions are excluded.

The live domain could not be reached from this environment (proxy tunnel failure). Apache/cPanel routing, live email delivery, production database permissions, and hosting PHP configuration remain hosting/staging checks. Deployment and rollback steps are in UPGRADE-PROLINK.md / READ-ME-FIRST.md.

## MySQL compatibility correction
The production MySQL unsigned sort_order column rejected the original negative priority. Portfolio entries now use 0 through 6. Regression checks require seven illustration projects and nonnegative sort positions. All 20 tests pass after the correction. Runtime tests remain SQLite-based; no production MySQL execution is claimed.
