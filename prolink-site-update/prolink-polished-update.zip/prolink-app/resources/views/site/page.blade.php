@extends('layouts.site')
@section('content')
<x-page-hero :page="$page" />
@if($page->kind==='article')
<section class="section-space"><div class="shell article-layout"><article class="article-body"><div class="article-meta">@if($page->published_at)<span>{{ $page->published_at->format('M j, Y') }}</span>@endif<span>Prolink Media Solutions</span><span>{{ max(1,(int)ceil(str_word_count(strip_tags($page->body))/200)) }} min read</span><span>{{ number_format($page->views) }} views</span></div>@if($page->image)<img class="article-image" src="{{ $page->image }}" alt="{{ $page->label }}" width="1000" height="600">@endif<div class="prose-content">{!! \App\Support\Site::present($page->body) !!}</div><div class="article-share"><span>Share this perspective</span><a href="https://wa.me/?text={{ urlencode(url($page->path)) }}" class="text-link">WhatsApp <x-icon /></a><button class="text-link" data-copy="{{ url($page->path) }}">Copy link <x-icon name="copy" /></button></div><section class="comments-section"><h2>Join the conversation</h2>@foreach($comments as $comment)<div class="comment"><strong>{{ $comment->name }}</strong><small>{{ \Carbon\Carbon::parse($comment->created_at)->format('M j, Y') }}</small><p>{{ $comment->body }}</p></div>@endforeach<form action="/comments/{{ $page->id }}" method="post" class="form-stack">@csrf<div class="form-grid"><label>Your name<input name="name" required maxlength="100" value="{{ old('name') }}"></label><label>Email (kept private)<input type="email" name="email" required maxlength="190" value="{{ old('email') }}"></label></div><label>Comment<textarea name="body" rows="4" required maxlength="3000">{{ old('body') }}</textarea></label><input class="honeypot" name="website" tabindex="-1" autocomplete="off"><small>Comments are reviewed before publication. <a href="/privacy">Privacy Notice</a></small><button class="button">Submit comment <x-icon name="send" /></button></form></section></article><aside class="article-aside"><span class="eyebrow">Ideas into action</span><h3>Let’s build your next chapter.</h3><p>From blog content to portfolio showcases, this hub is where your ideas are turned into compelling narratives for your audience.</p><a class="button" href="/contact">Talk to us <x-icon /></a><hr><a href="/blog" class="text-link">More perspectives <x-icon name="arrow-right" /></a></aside></div></section>
@if($relatedArticles->isNotEmpty())<section class="section-space related-insights"><div class="shell"><div class="section-heading"><div><span class="eyebrow">Keep exploring</span><h2>Another useful perspective.</h2></div><a href="/blog" class="text-link">All insights <x-icon /></a></div><div class="cards-grid">@foreach($relatedArticles as $item)<x-card :item="$item" />@endforeach</div></div></section>@endif
@elseif($page->kind==='team')
<section class="section-space profile-section">
    <div class="shell">
        <article class="profile-biography" aria-labelledby="profile-about-heading">
            <span class="eyebrow">The person behind the vision</span>
            <h2 id="profile-about-heading">About {{ $page->label }}</h2>
            <div class="prose-content profile-prose">{!! \App\Support\Site::present($page->body) !!}</div>
            <a href="/team" class="text-link profile-back-link"><x-icon name="arrow-left" /> Meet the Prolink team</a>
        </article>
    </div>
</section>
@else
<div class="migrated-content {{ $page->kind==='page'&&in_array($page->slug,['privacy','terms','faq'])?'legal-content':'' }}">{!! \App\Support\Site::present($page->body) !!}</div>
@endif
@endsection
