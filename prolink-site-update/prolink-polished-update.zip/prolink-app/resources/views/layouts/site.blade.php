<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="csrf-token" content="{{ csrf_token() }}">
@php($metaTitle=isset($page)?($page->seo_title?:$page->label.' | '.$settings['site_name']):$settings['site_name'])
@php($metaDescription=isset($page)?($page->seo_description?:$page->description):$settings['footer_description'])
<title>{{ $metaTitle }}</title><meta name="description" content="{{ $metaDescription }}"><link rel="canonical" href="{{ url()->current() }}">
<meta property="og:title" content="{{ $metaTitle }}"><meta property="og:description" content="{{ $metaDescription }}"><meta property="og:type" content="{{ isset($page)&&$page->kind==='article'?'article':'website' }}"><meta property="og:url" content="{{ url()->current() }}"><meta property="og:image" content="{{ url(($page->image??null)?:$settings['logo']) }}"><meta name="twitter:card" content="summary_large_image">
<meta name="theme-color" content="#241139"><link rel="icon" type="image/svg+xml" href="/favicon.svg"><link rel="stylesheet" href="/assets/app.css"><link rel="stylesheet" href="/assets/studio.css?v=20261025-1">
<style>:root{--studio-primary:{{ ($settings['brand_orange']??'#f97316')==='#f97316'?'#5c3c86':$settings['brand_orange'] }};--studio-secondary:{{ ($settings['brand_blue']??'#2563eb')==='#2563eb'?'#336da5':$settings['brand_blue'] }};--studio-tertiary:{{ ($settings['brand_indigo']??'#4f46e5')==='#4f46e5'?'#5c3c86':$settings['brand_indigo'] }};--orange:{{ $settings['brand_orange']??'#f97316' }};--blue:{{ $settings['brand_blue']??'#2563eb' }};--indigo:{{ $settings['brand_indigo']??'#4f46e5' }}}</style>
<link rel="stylesheet" href="/assets/testimonials.css?v=20261020-2">
<script>
(()=>{
const defaultTheme = @json($settings['default_theme']??'system');
let choice;
try { choice = localStorage.getItem('prolink-theme'); } catch(e) {}
if(choice !== 'light' && choice !== 'dark') choice = defaultTheme;
if(choice !== 'light' && choice !== 'dark') choice = typeof matchMedia === 'function' && matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
document.documentElement.classList.toggle('dark', choice === 'dark');
})();
</script>
<script defer src="/assets/lucide.js"></script><script defer src="/assets/app.js?v=20261019-3"></script><script defer src="/assets/navigation.js?v=20261025-1"></script>
<script type="application/ld+json">{!! json_encode(['@context'=>'https://schema.org','@type'=>'Organization','name'=>$settings['site_name'],'url'=>url('/'),'logo'=>url($settings['logo']),'email'=>$settings['email'],'telephone'=>$settings['phone']],JSON_UNESCAPED_SLASHES|JSON_HEX_TAG) !!}</script>
</head>
<body class="site-body studio-site">
<a class="skip-link" href="#main">Skip to content</a>
<div class="top-strip"><div class="shell"><span>Independent thinking. Connected expertise.</span><div><a href="mailto:{{ $settings['email'] }}">{{ $settings['email'] }}</a><span class="top-divider"></span><a href="tel:{{ $settings['phone'] }}">{{ $settings['phone'] }}</a></div></div></div>
<header class="site-header" id="site-header"><div class="shell nav-shell">
<a href="/" class="logo-link" aria-label="Prolink Media Solutions home"><img src="{{ $settings['logo'] }}" alt="{{ $settings['site_name'] }}" width="210" height="70"></a>
<nav class="desktop-nav" aria-label="Main navigation">
@foreach(json_decode($settings['navigation']??'[]',true) as $nav)
@if($nav['url']==='/what-we-do')
<div class="mega-parent"><button class="nav-link {{ request()->is('what-we-do','web-development','mobile-app-development','brand-visual-design','media-content-studio','renewable-energy-solutions','it-consultancy','it-training')?'active':'' }}" aria-expanded="false" aria-controls="services-mega" data-mega-toggle>{{ $nav['label'] }} <x-icon name="chevron-down" /></button>
<div class="mega-menu" id="services-mega" hidden><div class="mega-intro"><span class="eyebrow">The Prolink advantage</span><h3>One partner.<br>Every possibility.</h3><p>Connected expertise, from the first idea to lasting impact.</p><a href="/what-we-do" class="text-link">Explore all services <x-icon /></a></div><div class="mega-links">@foreach($services as $service)<a href="{{ $service->path }}"><span class="icon-box"><x-icon :name="$service->icon" /></span><span>{{ $service->label }}<small>{{ \Illuminate\Support\Str::limit($service->description,62) }}</small></span><x-icon /></a>@endforeach</div></div></div>
@elseif($nav['url']==='/about')
<div class="mega-parent compact-parent"><button class="nav-link {{ request()->is('about','team*')?'active':'' }}" aria-expanded="false" aria-controls="company-menu" data-mega-toggle>{{ $nav['label'] }} <x-icon name="chevron-down" /></button><div class="company-menu" id="company-menu" hidden><a href="/about"><x-icon name="building-2" /><span>Our story<small>Purpose, people and principles</small></span></a><a href="/team"><x-icon name="users" /><span>Our team<small>The people behind the work</small></span></a><a href="/faq"><x-icon name="messages-square" /><span>FAQs<small>Your questions, answered</small></span></a></div></div>
@else<a class="nav-link {{ request()->getPathInfo()===$nav['url']?'active':'' }}" href="{{ $nav['url'] }}">{{ $nav['label'] }}</a>@endif
@endforeach
</nav>
<div class="nav-actions"><button class="theme-toggle" data-theme-toggle aria-label="Toggle light and dark theme"><x-icon name="sun-moon" /></button><a href="/contact" class="button small nav-cta">Start a project <x-icon /></a><button class="mobile-toggle" aria-label="Open navigation" aria-expanded="false" aria-controls="mobile-nav"><x-icon name="menu" /></button></div>
</div></header>
<div id="mobile-nav" class="mobile-nav" role="dialog" aria-modal="true" aria-labelledby="drawer-title" tabindex="-1" hidden>
    <div class="mobile-nav-head">
        <a href="/" class="logo-link drawer-brand" aria-label="Prolink Media Solutions home"><img src="{{ $settings['logo'] }}" alt="{{ $settings['site_name'] }}" width="180" height="60"></a>
        <button type="button" data-close-menu aria-label="Close navigation"><x-icon name="x" /></button>
    </div>
    <div class="drawer-intro"><span class="eyebrow">Connect. Create. Elevate.</span><h2 id="drawer-title">Explore Prolink.</h2></div>
    <nav class="drawer-navigation" aria-label="Mobile navigation">
        @foreach(json_decode($settings['navigation']??'[]',true) as $nav)
            @if($nav['url']==='/what-we-do')
                <details class="drawer-group">
                    <summary><x-icon name="layers" /><span>{{ $nav['label'] }}</span><x-icon name="chevron-down" /></summary>
                    <div class="drawer-submenu">
                        <a href="/what-we-do">All services <x-icon name="arrow-up-right" /></a>
                        @foreach($services as $service)<a href="{{ $service->path }}" @if(request()->getPathInfo()===$service->path) aria-current="page" @endif><x-icon :name="$service->icon" /><span>{{ $service->label }}</span></a>@endforeach
                    </div>
                </details>
            @elseif($nav['url']==='/about')
                <details class="drawer-group">
                    <summary><x-icon name="building-2" /><span>{{ $nav['label'] }}</span><x-icon name="chevron-down" /></summary>
                    <div class="drawer-submenu"><a href="/about">Our story <x-icon name="arrow-up-right" /></a><a href="/team">Our team <x-icon name="users" /></a><a href="/faq">Frequently asked questions <x-icon name="circle-help" /></a></div>
                </details>
            @else
                @php($drawerIcon=match($nav['url']){'/'=>'house','/portfolio'=>'briefcase-business','/blog'=>'notebook-text','/contact'=>'messages-square',default=>'arrow-up-right'})
                <a href="{{ $nav['url'] }}" @if(request()->getPathInfo()===$nav['url']) aria-current="page" @endif><x-icon :name="$drawerIcon" /><span>{{ $nav['label'] }}</span><x-icon name="arrow-up-right" /></a>
            @endif
        @endforeach
    </nav>
    <div class="drawer-bottom">
        <a href="/contact" class="button drawer-project-link">Start a project <x-icon name="arrow-up-right" /></a>
        <div class="drawer-contact"><a href="tel:{{ $settings['phone'] }}"><x-icon name="phone" />{{ $settings['phone'] }}</a><a href="mailto:{{ $settings['email'] }}"><x-icon name="mail" />{{ $settings['email'] }}</a></div>
        <button type="button" class="drawer-theme" data-theme-toggle aria-label="Toggle light and dark theme"><x-icon name="sun-moon" /><span data-theme-label>Change appearance</span><x-icon name="arrow-right" /></button>
    </div>
</div>
<div class="menu-backdrop" aria-hidden="true" hidden></div>
<main id="main">
@if(session('success'))<div class="shell"><div role="status" class="notice success"><x-icon name="circle-check" />{{ session('success') }}</div></div>@endif
@if($errors->any())<div class="shell"><div class="notice error" role="alert"><ul>@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div></div>@endif
@yield('content')
</main>
<section class="project-band"><div class="shell"><div><span class="eyebrow">{{ $copy['cta_eyebrow']??"Your next chapter starts here" }}</span><h2>{!! nl2br(e($copy['cta_heading']??"Have a vision?\nLet’s bring it to life.")) !!}</h2><p>{{ $copy['cta_description']??"Tell us about your project and we'll respond with practical next steps." }}</p></div><a class="circle-cta" href="/contact" aria-label="Start a project"><x-icon name="arrow-up-right" /><span>Let’s talk</span></a></div></section>
<footer class="site-footer"><div class="shell"><section class="footer-newsletter" aria-labelledby="newsletter-heading"><div class="newsletter-intro"><span class="eyebrow">Good ideas. In your inbox.</span><h3 id="newsletter-heading">{{ $copy['newsletter_heading']??"Stay ahead with Prolink insights." }}</h3><p>{{ $copy['newsletter_description']??"Occasional updates on digital, media, energy and consultancy." }}</p></div><form method="post" action="/subscribe" class="newsletter-form">@csrf<label class="newsletter-label" for="newsletter-email">Email address</label><div class="email-entry"><input id="newsletter-email" type="email" name="email" autocomplete="email" inputmode="email" placeholder="you@example.com" required maxlength="190" aria-describedby="newsletter-reassurance"><button type="submit"><span>Subscribe</span><x-icon name="arrow-right" /></button></div><label class="consent"><input type="checkbox" name="newsletter_consent" value="1" required><span>I agree to receive Prolink updates. Read our <a href="/privacy">Privacy Notice</a>.</span></label><p class="newsletter-reassurance" id="newsletter-reassurance">Occasional emails. Unsubscribe at any time.</p><input type="text" name="website" tabindex="-1" autocomplete="off" class="honeypot" aria-hidden="true"></form></section>
<div class="footer-grid"><div class="footer-brand"><a href="/" class="logo-link"><img src="{{ $settings['logo'] }}" alt="{{ $settings['site_name'] }}" width="210" height="70" loading="lazy"></a><p>{{ $settings['footer_description'] }}</p><span class="footer-tagline">{{ $settings['tagline'] }}</span></div><div><h4>Company</h4>@foreach([['About us','/about'],['Our work','/portfolio'],['Our team','/team'],['Insights','/blog'],['FAQs','/faq'],['Contact','/contact']] as [$label,$url])<a href="{{ $url }}">{{ $label }}</a>@endforeach</div><div><h4>Our expertise</h4>@foreach($services as $service)<a href="{{ $service->path }}">{{ $service->label }}</a>@endforeach</div><div><h4>Let’s connect</h4><a href="tel:{{ $settings['phone'] }}">{{ $settings['phone'] }}</a><a href="tel:{{ $settings['phone_secondary'] }}">{{ $settings['phone_secondary'] }}</a><a href="mailto:{{ $settings['email'] }}">{{ $settings['email'] }}</a><p>{!! nl2br(e($settings['address'])) !!}</p></div></div><div class="footer-bottom"><span>© {{ date('Y') }} {{ $settings['site_name'] }}. All rights reserved.</span><div><a href="/privacy">Privacy</a><a href="/terms">Terms</a><span>Designed by Prolink Media Solutions</span></div></div></div></footer>
<aside class="contact-widget" aria-label="Contact Prolink">
    <section class="contact-float" id="prolink-contact-card" aria-labelledby="contact-card-title" hidden inert>
        <div class="contact-float-inner">
            <button class="contact-float-close" type="button" aria-label="Close contact card"><x-icon name="x" /></button>
            <div class="contact-float-heading"><span class="contact-float-icon"><x-icon name="messages-square" /></span><div><span class="contact-float-kicker">LET’S CREATE SOMETHING</span><h2 id="contact-card-title">Your next idea starts here.</h2></div></div>
            <p>Have a project in mind? Talk to the Prolink team about bringing it to life.</p>
            <a class="contact-float-action" href="https://wa.me/{{ $settings['whatsapp'] }}" target="_blank" rel="noopener noreferrer">Let’s talk on WhatsApp <x-icon name="arrow-up-right" /></a>
            <span class="contact-float-note">Opens WhatsApp. Send your message when ready.</span>
        </div>
    </section>
    <button class="contact-launcher" type="button" aria-label="Open Prolink contact card" aria-controls="prolink-contact-card" aria-expanded="false" hidden><x-icon name="message-circle" /><span class="contact-launcher-label">Let’s talk</span></button>
    <noscript><a class="contact-fallback" href="https://wa.me/{{ $settings['whatsapp'] }}">WhatsApp</a></noscript>
</aside>
<button class="back-to-top" aria-label="Back to top" hidden><x-icon name="arrow-up" /></button>
<script defer src="/assets/newsletter.js?v=20261020-1"></script>
<script defer src="/assets/contact-card.js?v=20261025-1"></script>
<script defer src="/assets/testimonials.js?v=20261020-2"></script>
@stack('scripts')
</body></html>
