<?php
namespace Database\Seeders;
use App\Models\Page;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
class DatabaseSeeder extends Seeder {
 public function run():void {
  foreach(json_decode(file_get_contents(database_path('content/pages.json')),true) as $row){$views=$row['initial_views']??0;unset($row['initial_views']);$page=Page::firstOrCreate(['path'=>$row['path']],$row);if($page->wasRecentlyCreated&&$views)$page->forceFill(['views'=>$views])->save();}
  $this->call([PortfolioExperienceSeeder::class, StudioDesignSeeder::class]);
  $settings=json_decode(file_get_contents(database_path('content/settings.json')),true);
  foreach($settings as $key=>$value)DB::table('settings')->insertOrIgnore(['key'=>$key,'value'=>is_array($value)?json_encode($value):$value,'created_at'=>now(),'updated_at'=>now()]);
  foreach(glob(public_path('media/*')) as $file){DB::table('media')->insertOrIgnore(['path'=>'/media/'.basename($file),'name'=>basename($file),'alt'=>pathinfo($file,PATHINFO_FILENAME),'size'=>filesize($file),'created_at'=>now(),'updated_at'=>now()]);}
 }
}
