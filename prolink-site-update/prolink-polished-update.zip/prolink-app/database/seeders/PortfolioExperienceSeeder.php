<?php
namespace Database\Seeders;
use App\Models\Page;
use Illuminate\Database\Seeder;
class PortfolioExperienceSeeder extends Seeder
{
 public function run(): void
 {
  $projects = [
   ['omega-fire-ministries-los-angeles','Omega Fire Ministries, Los Angeles','Church media & website development','Website Development','globe','/media/65702e262ce0bb1044.png','Media support and website development for Omega Fire Ministries, Los Angeles.','Website development and media support to serve the ministry’s digital communication.'],
   ['lineagecare-foundation','LineageCare Foundation','Foundation website','Website Development','heart-handshake','/media/0887113b312e950efe.png','Website work for LineageCare Foundation.','A digital presence for communicating the foundation’s identity and work.'],
   ['livingway-world-church','Livingway World Church','Complete church media setup','Media & Content','radio','/media/f149060557b9f94ac2.png','Total media setup for Livingway World Church.','Bringing the church’s media setup together around its communication needs.'],
   ['church-of-god-mission-sunderland','Church of God Mission Sunderland','Church website','Website Development','church','/media/65702e262ce0bb1044.png','Website work for Church of God Mission Sunderland.','Website development to support the church’s online presence.'],
   ['cgmi-diaspora','CGMI Diaspora','Ministry website','Website Development','globe','/media/0887113b312e950efe.png','Website work for CGMI Diaspora.','Website development for the ministry’s digital presence.'],
   ['matthew-omondiale-mentorship-institute','Matthew Omondiale Mentorship Institute','Institute website','Website Development','graduation-cap','/media/9773164749a441121b.png','Website development for Matthew Omondiale Mentorship Institute.','An institutional website presenting the institute and its mentorship focus.'],
   ['smti','SMTI','Institutional website','Website Development','book-open','/media/65702e262ce0bb1044.png','Website work for SMTI.','Website development aligned with the institution’s online communication needs.'],
  ];
  foreach($projects as $i=>[$slug,$name,$scope,$category,$icon,$image,$summary,$contribution]) {
   $image='/assets/projects/'.$slug.'.svg';
   $body='<section class="content-section"><div class="content-wrap"><div class="content-grid"><div class="span-7"><span class="section-title">PROJECT CONTEXT</span><h2>'.e($name).'</h2><p>'.e($summary).'</p><h3>Our contribution</h3><p>'.e($contribution).'</p><p>Have a similar brief? We can discuss your audience, requirements, and the right approach for your organisation.</p><a class="content-button" href="/contact?service='.rawurlencode($category).'">Discuss a similar project</a></div><aside class="span-5 content-card"><span class="section-title">PROJECT AT A GLANCE</span><h3>'.e($scope).'</h3><p>Organisation: '.e($name).'</p><p>Discipline: '.e($category).'</p><p class="small">The accompanying graphic is a project illustration, not a client logo or website screenshot.</p><a class="text-link" href="/portfolio">Back to all projects</a></aside></div></div></section>';
   Page::firstOrCreate(['path'=>'/project/'.$slug],['slug'=>'project/'.$slug,'label'=>$name,'title'=>$name,'description'=>$summary,'kind'=>'project','category'=>$category,'icon'=>$icon,'image'=>$image,'body'=>$body,'published'=>true,'sort_order'=>$i]);
  }
 }
}
