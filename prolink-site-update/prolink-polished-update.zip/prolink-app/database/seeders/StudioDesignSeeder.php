<?php
namespace Database\Seeders;
use App\Models\Page;
use Illuminate\Database\Seeder;
class StudioDesignSeeder extends Seeder
{
 public function run(): void
 {
  // Only improve the shipped default copy; preserve any user-customised homepage.
  $home=Page::where('path','/')->first();
  if($home && $home->title==='We design experiences that move people and power organisations.') {
   $home->forceFill(['title'=>'Digital experiences. Built with purpose.','description'=>'Websites, design, media, and technology — connected around your goals. We help businesses, ministries, and institutions turn a clear vision into a stronger presence.'])->save();
  }
 }
}
