<?php
namespace App\Http\Controllers;
use App\Models\Page;
use App\Support\Site;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
class SiteController extends Controller {
 public function page(Request $request,string $path='') {
  $page=Page::published()->where('path','/'.trim($path,'/'))->firstOrFail();
  if(in_array($page->kind,['article','project']))$page->increment('views');
  $query=Page::published()->orderBy('sort_order');$data=['page'=>$page];
  $template=match($page->slug){'home'=>'home','portfolio'=>'listing','blog'=>'listing','team'=>'listing','contact'=>'contact',default=>'page'};
  if($template==='home'){$data['projects']=(clone $query)->where('kind','project')->limit(3)->get();$data['articles']=(clone $query)->where('kind','article')->limit(3)->get();$data['team']=(clone $query)->where('kind','team')->get();}
  if($template==='listing'){
   $kind=match($page->slug){'portfolio'=>'project','blog'=>'article',default=>'team'};
   $items=(clone $query)->where('kind',$kind);
   if($request->filled('q'))$items->where(function($q)use($request){$q->where('title','like','%'.$request->string('q').'%')->orWhere('description','like','%'.$request->string('q').'%');});
   if($request->filled('category'))$items->where('category',$request->string('category'));
   $data['items']=$items->paginate(9)->withQueryString();$data['categories']=Page::published()->where('kind',$kind)->whereNotNull('category')->where('category','!=','')->distinct()->pluck('category');
  }
  if($page->kind==='article') { $data['comments']=DB::table('comments')->where('page_id',$page->id)->where('approved',true)->latest()->get(); $data['relatedArticles']=Page::published()->where('kind','article')->where('id','!=',$page->id)->orderByDesc('published_at')->limit(3)->get(); }
  if($page->kind==='service') { $page->body=preg_replace('/href=([\"\'])\/contact\1/', 'href="/contact?service='.rawurlencode($page->label).'"', $page->body); }
  return view('site.'.$template,$data);
 }
 public function contact(Request $r){
  $v=$r->validate(['name'=>'required|string|max:150','email'=>'required|email|max:190','phone'=>'nullable|string|max:40','service'=>'nullable|string|max:190','message'=>'required|string|min:10|max:10000','consent'=>'accepted','website'=>'nullable|max:0']);
  unset($v['consent'],$v['website']);DB::table('inquiries')->insert($v+['status'=>'new','created_at'=>now(),'updated_at'=>now()]);
  if(config('prolink.notify_mail')){try{Mail::raw("New website enquiry from {$v['name']} ({$v['email']})\n\n{$v['message']}",fn($m)=>$m->to(Site::get('email'))->subject('New Prolink website enquiry'));}catch(\Throwable $e){report($e);}}
  return back()->with('success','Your message has been received. Our team will be in touch.');
 }
 public function subscribe(Request $r){$v=$r->validate(['email'=>'required|email|max:190','newsletter_consent'=>'accepted','website'=>'nullable|max:0']);DB::table('subscribers')->updateOrInsert(['email'=>$v['email']],['token'=>Str::random(64),'consented_at'=>now(),'unsubscribed_at'=>null,'created_at'=>now(),'updated_at'=>now()]);$message='Thank you. You are subscribed to Prolink insights.';return $r->expectsJson()?response()->json(['message'=>$message]):back()->with('success',$message);}
 public function unsubscribe(string $token){$s=DB::table('subscribers')->where('token',$token)->first();abort_unless($s,404);return view('site.unsubscribe',['token'=>$token,'done'=>$s->unsubscribed_at!==null]);}
 public function unsubscribeConfirm(string $token){abort_unless(DB::table('subscribers')->where('token',$token)->exists(),404);DB::table('subscribers')->where('token',$token)->update(['unsubscribed_at'=>now(),'updated_at'=>now()]);return view('site.unsubscribe',['token'=>$token,'done'=>true]);}
 public function comment(Request $r,Page $page){abort_unless($page->published&&$page->kind==='article',404);$v=$r->validate(['name'=>'required|string|max:100','email'=>'required|email|max:190','body'=>'required|string|min:3|max:3000','website'=>'nullable|max:0']);unset($v['website']);DB::table('comments')->insert($v+['page_id'=>$page->id,'approved'=>false,'created_at'=>now(),'updated_at'=>now()]);return back()->with('success','Thank you. Your comment is awaiting review.');}
 public function sitemap(){return response()->view('site.sitemap',['pages'=>Page::published()->get()])->header('Content-Type','application/xml');}
}
